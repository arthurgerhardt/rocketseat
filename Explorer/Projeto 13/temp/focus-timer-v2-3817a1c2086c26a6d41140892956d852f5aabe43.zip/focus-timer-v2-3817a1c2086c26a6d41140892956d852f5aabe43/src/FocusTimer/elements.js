export const controls = document.getElementById('controls')

export const minutes = document.getElementById('minutes')
export const seconds = document.getElementById('seconds')