export default {
    minutes: 25,
    seconds: 0,
    isRunning: false,
    isMute: true,
}