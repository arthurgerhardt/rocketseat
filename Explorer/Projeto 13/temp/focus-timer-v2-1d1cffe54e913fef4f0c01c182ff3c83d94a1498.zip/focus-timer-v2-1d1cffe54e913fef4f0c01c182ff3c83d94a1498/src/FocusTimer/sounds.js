export const buttonPressAudio = new Audio('./assets/button-press.wav')
export const kitchenTimer = new Audio('./assets/kichen-timer.mp3')
export const bgAudio = new Audio('./assets/bg-audio.mp3')

