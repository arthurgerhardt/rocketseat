import './toggle-mode.js'
import * as FocusTimer from "./FocusTimer/index.js"

FocusTimer.start(0, 6)
